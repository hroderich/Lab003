//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)

//Optional Operator
var testOptional = Optional("Hello Optional")
var testOptional2:String? = "Second Optional"
print("The string is: \(testOptional!)")
print("The second string is: \(testOptional2!)")

let myString = "banana"
let posibleInt = Int(myString)
print(posibleInt)


var arrayList = ["1", "2", "3", "4"]
print(arrayList)
arrayList[1] = "200"
print(arrayList)


let number = 34

if number < 10 {
print("The number is small")
}else if number > 100{
print("The number is Big")
}else{
print("Other Number")
}

//Function ans methods
func getValue (name:String, ci:Int) ->String {
return "the name of value is \(name) and CI \(ci)"
}

getValue("Rodrigo", ci: 123456)

var array = ["1", "2"]
array.insert("0", atIndex: 0)

//Class without constructor
class Shape {
    var numberOfSides = 0
    
    func simpleDescription() -> String{
    return "this is a Shape class number os sides \(numberOfSides)"
    }
}

var shape = Shape()
shape.numberOfSides = 10
shape.simpleDescription()

//Class with constructor
class NamedShape{
    var numberOfSides = 0
    var name:String
    //Constructor
    init(name:String){
        self.name = name
    }
    func getDescription() -> String{
        return "The description is \(name)"
    }
}

var nameShape = NamedShape(name: "Rodrigo")
nameShape.getDescription()

//Herencia
class Square:NamedShape{
    var sideLength:Double
    init(sideLength:Double, name:String){
        self.sideLength = sideLength
        super.init(name: name)
        numberOfSides = 5
    }
    
    func area() -> Double{
        return sideLength*sideLength
    }
}

var square = Square(sideLength: 12.0, name: "Rodrigo")
square.area()
square.getDescription()

//Protocol
protocol Printable{
    func printShare()
}

class SquareT : Printable{
    func printShare() {
        print("Print SquareT")
    }
}

var t = SquareT()
t.printShare()

var simple:Printable = SquareT()
simple.printShare()



//Example

protocol Printables{
    func printShape()
}


class SquareA : Printables {
    func printShape()  {
        print ("is square")
    }
}

class Circle : Printables {
    func printShape()  {
        print ("is circle")
    }
}


class Printer{
    
    func Printable(printable: Printables){
        printable.printShape()
    }
    
}

var sq1 = Printer()
sq1.Printable(SquareA())
sq1.Printable(Circle())


